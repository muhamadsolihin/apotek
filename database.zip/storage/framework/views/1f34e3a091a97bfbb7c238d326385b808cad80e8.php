

<?php $__env->startSection('content'); ?>
<div class="container-fluid row">
    <div class="col-md-2 p-0">
        <?php echo $__env->make('_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-md-10 py-5 container">
        <form action="<?php echo e(route('pemasukan.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="d-flex flex-wrap justify-content-left">
                <div class="col-md-5">
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama</label>
                        <input type="text" class="form-control" id="nama" name="nama"
                            required>
                    </div>
                    <div class="mb-3">
                        <label for="tanggal" class="form-label">Tanggal Masuk</label>
                        <input type="date" class="form-control" id="tanggal" name="tanggal" required>
                    </div>
                    <div class="mb-3">
                        <label for="nominal" class="form-label"> Nominal</label>
                        <input type="text" class="form-control" id="nominal" name="nominal" required>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
    </div>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solihin\sistem-desa\resources\views/pemasukan/create.blade.php ENDPATH**/ ?>