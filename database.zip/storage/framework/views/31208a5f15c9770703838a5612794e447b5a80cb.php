

<?php $__env->startSection('content'); ?>
<div class="container-fluid row py-0">
    <div class="col-md-2 p-0">
        <?php echo $__env->make('_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="col-md-10  container py-5">

        <div class="mb-3 d-flex flex-wrap justify-content-end">
            <form action="<?php echo e(route('transaksi.index')); ?>" method="GET">
                <div class="input-group ml-auto">
                    <input type="text" class="form-control" placeholder="Cari Obat" name="search" value="<?php echo e($searchTerm); ?>">
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </form>
            <a class="btn btn-primary ms-3 " href="<?php echo e(route('transaksi.create')); ?>">Tambah</a>
        </div>
    <div class="d-flex flex-justify-between">
        <div class="chart ml-5 ms-3 p-2">
        <canvas  id="pieChart"></canvas>
        </div>
        <table class="table ms-3 table-bordered table-striped">
            <thead class="table-primary bg-primary">
                <tr>
                    <th>Jumlah</th>
                    <th>Nama Obat</th>
                    <th>Tangggal Pembelian</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $transaksiItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->jumlah_stok); ?></td>
                        <td><?php echo e($item->nama_obat); ?></td>
                        <td><?php echo e($item->expired_date); ?></td>
                        <td>
                            <a href="<?php echo e(route('transaksi.edit', $item->id)); ?>" class="btn btn-primary">Edit</a>
                            <form action="<?php echo e(route('transaksi.destroy', $item->id)); ?>" method="POST" style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this item?')">Delete</button>
                            </form>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
const pieChartCanvas = document.getElementById('pieChart'); // Replace 'pieChart' with the ID of your canvas element

const pieChart = new Chart(pieChartCanvas, {
  type: 'pie',
  data: {
    labels: ['Obat A', 'Obat B', 'Obat C'],
    datasets: [{
      data: [10, 35, 20],
      backgroundColor: [
        '#5F9EA0', // Green
        '#A9A9A9', // Red
        '#DB7093', 
        '#F08080'
        // Blue
      ],
      border:"none",
      borderWidth: 2,
    }],
  },
  options: {
    plugins: {
      legend: {
        position: 'top', // Customize legend position
      },
    },
    responsive: true, // Make the chart responsive
  },
});

fetch("<?php echo e(route('sales-data')); ?>")
    .then((response) => response.json())
    .then((data) => {
        const labels = data.map((item) => item.nama_obat);
        const values = data.map((item) => item.total);

        // Memperbarui data grafik dengan data yang diambil
        pieChart.data.labels = labels;
        pieChart.data.datasets[0].data = values;

        // Memperbarui grafik
        pieChart.update();
    })
    .catch((error) => {
        console.error(error);
    });



</script>

<style>
    
.chart{
       background-color:#fff;
       border-radius:10px;
       display:flex;
       justify:center;
       align-items:center;
        width:400px;
        height:400px;
 }
.scrolling-text {
  background-color: transparent; 
  color: #000; 
  padding:10px 0;

}

/* CSS for the marquee element */
marquee {
  font-size: 20px; /* Set the font size */
  font-weight: bold; /* Make the text bold */
  padding-left: 20px; /* Add left padding for spacing */
}

    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solihin\apotek\resources\views/transaksi/index.blade.php ENDPATH**/ ?>