

<?php $__env->startSection('content'); ?>
<div class="container-fluid row py-0">
    <div class="col-md-2 p-0">
        <?php echo $__env->make('_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="col-md-10  container py-5">
    <div class="d-flex flex-justify-between">
        <div class="chart ml-5 ms-3 p-2">
        </div>
        <table class="table ms-3 table-bordered table-striped">
        <thead class="table-primary bg-primary">
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Action</th>
                <th>Timestamp</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $historyLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($log->id); ?></td>
                    <td><?php echo e($log->user->name); ?></td>
                    <td><?php echo e($log->action); ?></td>
                    <td><?php echo e($log->timestamp); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solihin\apotek-pos\resources\views/history_logs/index.blade.php ENDPATH**/ ?>