<!DOCTYPE html>
<html>
<head>
    <title>Laporan PDF</title>
    <!-- Include your CSS styles here -->
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        h1 {
            color: #333;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid #333;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        header {
            text-align: left;
            margin-bottom: 20px;
        }

        footer {
            text-align: center;
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: #f2f2f2;
            padding: 10px;
        }
    </style>
</head>
<body>
    <header class="text-left">
        <!-- Isi header seperti kop surat di sini -->
        <h2>Apotek Aulia</h2>
        <p>Jl. A Yani No.115 Talaga Majalengka, Jawa Barat</p>
        <p>Nomor Telepon: 021-0287378</p>
    </header>

    <h3 class="text-left">Laporan Penjualan</h3>
    <!-- <p>S: <?php echo e($startDate); ?></p>
    <p>End Date: <?php echo e($endDate); ?></p> -->

    <table>
        <thead>
            <tr>
                <th>Id</th>
                <th>Jumlah</th>
                <th>Nama Obat</th>
                <th>Jenis Obat</th>
                <th>Tanggal Pembelian</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transaksiItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->jumlah_stok); ?></td>
                    <td><?php echo e($item->nama_obat); ?></td>
                    <td><?php echo e($item->jenis_obat); ?></td>
                    <td><?php echo e($item->expired_date); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <footer>
        <!-- Tambahkan tanda tangan atau informasi lain di footer di sini -->
        <p>Tanda Tangan: __________________________</p>
        <p>Tanggal: <?php echo e(date('Y-m-d')); ?></p>
    </footer>
</body>
</html>
<?php /**PATH C:\Users\solihin\apotek-pos\resources\views/laporan/pdf.blade.php ENDPATH**/ ?>