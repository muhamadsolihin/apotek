

<?php $__env->startSection('content'); ?>
<div class="container-fluid row">
    <div class="col-md-2 p-0">
        <?php echo $__env->make('_sidebarUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-md-10 py-3 container">
        <h5 class="h-1 mb-5" style="color:#000;"> Status Pengajuan Surat
            <table class="table mt-3 table-bordered table-striped ">
                <thead class="table-primary bg-primary">
                    <tr>
                        <th>Jenis Pengajuan</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kelahiran_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->type); ?></td>
                        <td><?php echo e($item->status); ?></td>
                        <td>
                            <?php if($item->type == 'kelahiran'): ?>
                            <a href="<?php echo e(route('kelahiran.edit', $item->id)); ?>" class="btn btn-info">Detail</a>
                            <?php elseif($item->type == 'kematian'): ?>
                            <a href="<?php echo e(route('kematian.edit', $item->id)); ?>" class="btn btn-info">Detail</a>
                            <?php elseif($item->type == 'sktm'): ?>
                            <a href="<?php echo e(route('sktm.edit', $item->id)); ?>" class="btn btn-info">Detail</a>
                            <?php endif; ?>

                            <?php if(Auth::user()->role == 'rt' && $item->status == 'onproses'): ?>
                                <a href="<?php echo e(route('approve', ['id' => $item->id])); ?>"
                                    class="btn btn-success btn-sm">Approve</a>
                                <a href="<?php echo e(route('reject', ['id' => $item->id])); ?>"
                                    class="btn btn-danger btn-sm">Reject</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class="d-flex justify-content-center">
            </div>
    </div>
</div>

<?php $__env->stopSection(); ?>




<style>
    #notificationIcon {
        cursor: pointer;
        transition: transform 0.2s ease-in-out;
    }

    #notificationIcon:hover {
        transform: scale(1.1);
    }

    #notificationIcon img {
        transition: opacity 0.2s ease-in-out;
    }

    #notificationIcon:hover img {
        opacity: 0.8;
    }

    #notificationBadge {
        transition: background-color 0.2s ease-in-out, transform 0.2s ease-in-out;
    }

    #notificationIcon:hover #notificationBadge {
        background-color: #ff5733;
        /* Warna latar merah saat hover */
        transform: scale(1.1);
        /* Perbesar badge saat hover */
    }
</style>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solihin\sistem-desa\resources\views/kelahiran/index.blade.php ENDPATH**/ ?>