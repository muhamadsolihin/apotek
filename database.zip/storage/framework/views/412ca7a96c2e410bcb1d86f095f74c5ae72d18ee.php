

<?php $__env->startSection('content'); ?>
    <div class="container-fluid row">
            <div class="col-md-2 p-0">
                <?php echo $__env->make('_sidebarPemilik', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Include the sidebar -->
            </div>
            <div class="col-md-10">
                <?php echo $__env->make('_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Include the dashboard content -->
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solihin\apotek-pos\resources\views/penjual.blade.php ENDPATH**/ ?>