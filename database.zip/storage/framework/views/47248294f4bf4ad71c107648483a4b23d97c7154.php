

<?php $__env->startSection('content'); ?>
    <div class="container-fluid row d-flex ">
            <div class="sidebar col-md-2">
                <?php echo $__env->make('_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Include the sidebar -->
            </div>
            <div class="col-md-10 ">
                <?php echo $__env->make('_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Include the dashboard content -->
            </div>
        </div>
<?php $__env->stopSection(); ?>

<style>
    .content-full{
        padding:0 !important;
    }
</style>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solihin\apotek-pos\resources\views/admin.blade.php ENDPATH**/ ?>