

<?php $__env->startSection('content'); ?>
<div class="container-fluid row">
    <div class="col-md-2 p-0">
        <?php echo $__env->make('_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-md-10 py-5 container">
        <h5 class="fw-bold mb-3">Daftar Obat yang Telah Kadaluarsa</h5>
        <table class="table table-bordered table-striped">
            <thead class="table-primary bg-primary">
                <tr>
                    <th>Nama Obat</th>
                    <th>Jenis Obat</th>
                    <th>Jumlah Stok</th>
                    <th>Tanggal Kadaluarsa</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $expiredInventoryItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->nama_obat); ?></td>
                        <td><?php echo e($item->jenis_obat); ?></td>
                        <td><?php echo e($item->jumlah_stok); ?></td>
                        <td><?php echo e($item->expired_date); ?></td>
                        <td>
                            <?php if(now() > $item->expired_date): ?>
                                <span class="h-2 fw-bold">Telah Kadaluarsa</span>
                            <?php elseif(now()->addMonths(3) >= $item->expired_date): ?>
                                <span class="h-3 fw-bold">Mendekati Masa Kadaluarsa</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solihin\apotek-pos\resources\views/expired_inventory.blade.php ENDPATH**/ ?>