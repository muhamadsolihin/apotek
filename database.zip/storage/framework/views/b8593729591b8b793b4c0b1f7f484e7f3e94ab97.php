

<?php $__env->startSection('content'); ?>
<div class="container-fluid row">
    <div class="col-md-2 p-0">
        <?php echo $__env->make('_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-md-10 py-5 container">
        <!-- Add New Item Form -->
        <form action="<?php echo e(route('transaksi.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
     <label for="nama_obat" class="form-label">Nama Obat</label>
     <select class="form-select" id="nama_obat" name="nama_obat" required>
    <option value="" selected disabled>Pilih Nama Obat</option>
    <?php $__currentLoopData = $inventoryItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $nama_obat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($nama_obat); ?>"><?php echo e($nama_obat); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

        </div>
            <div class="mb-3">
                <label for="jenis_obat" class="form-label">Jenis Obat</label>
                <input type="text" class="form-control" id="jenis_obat" name="jenis_obat" required>
            </div>
            <div class="mb-3">
                <label for="jumlah_stok" class="form-label">Jumlah</label>
                <input type="number" class="form-control" id="jumlah_stok" name="jumlah_stok" required>
            </div>
            <div class="mb-3">
                <label for="tanggal_kadaluarsa" class="form-label">Tanggal Pembelian</label>
                <input type="date" class="form-control" id="expired_Date" name="expired_Date" required>
            </div>
            <button type="submit" class="btn btn-primary">Add Item</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solihin\apotek-pos\resources\views/transaksi/create.blade.php ENDPATH**/ ?>