

<?php $__env->startSection('content'); ?>
<div class="container-fluid row">
    <div class="col-md-2 p-0">
        <?php echo $__env->make('_sidebarPemilik', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-md-10 py-5 container">
        <div class="mb-3 d-flex flex-wrap justify-content-between">
            <a class="btn btn-primary" href="<?php echo e(route('inventorypemilik.create')); ?>">Tambah Obat</a>

            <form action="<?php echo e(route('inventorypemilik.index')); ?>" method="GET">
                <div class="input-group ml-auto">
                    <input type="text" class="form-control" placeholder="Cari Obat" name="search" value="<?php echo e($searchTerm); ?>">
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </form>
        </div>
        
        <table class="table table-bordered table-striped">
            <thead class="table-primary bg-primary">
                <tr>
                    <th>Nama Obat</th>
                    <th>Jenis Obat</th>
                    <th>Jumlah Stok</th>
                    <th>Tanggal Kadaluarsa</th>
                    <th>Keterangan</th>
                    <th>Action</th> <!-- Add this column for Edit and Delete buttons -->
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $inventoryItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->nama_obat); ?></td>
                        <td><?php echo e($item->jenis_obat); ?></td>
                        <td><?php echo e($item->jumlah_stok); ?></td>
                        <td><?php echo e($item->expired_date); ?></td>
                        <td>
                            <?php if(now() > $item->expired_date): ?>
                                <span class="h-2 fw-bold">Telah Kadaluarsa</span>
                            <?php elseif(now()->addMonths(3) >= $item->expired_date): ?>
                                <span class="h-3 fw-bold">Mendekati Masa Kadaluarsa</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('inventory.edit', $item->id)); ?>" class="btn btn-primary">Edit</a>
                            <form action="<?php echo e(route('inventory.destroy', $item->id)); ?>" method="POST" style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this item?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="d-flex justify-content-center">
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solihin\apotek-pos\resources\views/inventorypemilik/index.blade.php ENDPATH**/ ?>