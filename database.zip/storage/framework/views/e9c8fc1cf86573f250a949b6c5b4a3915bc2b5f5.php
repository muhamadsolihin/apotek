<div class="sidebar h-full py-2 px-2">
    <ul class="nav flex-column">
        <li class="nav-item">
            <!-- <a class="nav-link text-dark fw-bold" href="/home">Dashboard</a> -->
        </li>
        <li class="nav-item">
            <a class="nav-link text-white fw-bold" href="<?php echo e(url('/inventory/user')); ?>">
                <i class="bi bi-box me-2"></i> Pemeliharaan Stok Obat
            </a>
        </li>
        <li class="nav-item">
            <button class="btn btn-success py-2 px-2 text-light fw-bold" onclick="window.location.href='https://api.whatsapp.com/send?phone=6281573536638&text=Hello%20Apothecary%20Aulia,%20saya%20mau%20konsultasi%20dong'">Contact via WhatsApp</button>
        </li>
        <!-- Add more navigation links as needed -->
    </ul>
</div>
<?php /**PATH C:\Users\solihin\apotek-pos\resources\views/_sidebarUser.blade.php ENDPATH**/ ?>