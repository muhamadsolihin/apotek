<div class="sidebar h-full py-2">
    <ul class="nav flex-column">
        <li class="nav-item">
            <a class="nav-link text-white fw-bold"  href="<?php echo e(url('/penjual')); ?>">
                <i class="bi bi-house-door text-body me-2"></i> Dashboard
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white fw-bold" href="<?php echo e(url('/inventory/pemilik')); ?>">
                <i class="bi bi-box me-2"></i> Pemeliharaan Stok Obat
            </a>
        </li>
        <!-- <li class="nav-item">
            <a class="nav-link text-dark fw-bold" href="<?php echo e(url('/transaksi')); ?>">
                <i class="bi bi-cart me-2"></i> Transaksi Penjualan
            </a>
        </li> -->
        <li class="nav-item">
            <a class="nav-link text-white fw-bold" href="<?php echo e(url('/laporan/pemilik')); ?>">
                <i class="bi bi-file-text me-2"></i> Laporan Penjualan
            </a>
        </li>
        <!-- Add more navigation links as needed -->
    </ul>
</div>
<?php /**PATH C:\Users\solihin\apotek-pos\resources\views/_sidebarPemilik.blade.php ENDPATH**/ ?>