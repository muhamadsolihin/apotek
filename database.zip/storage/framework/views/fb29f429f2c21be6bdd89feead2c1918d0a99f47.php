

<?php $__env->startSection('content'); ?>
    <div class="container-fluid row">
            <div class="col-md-2 p-0">
                <?php echo $__env->make('_sidebarUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            </div>
            <div class="col-md-10">
                <?php echo $__env->make('dashboardUmum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\solihin\sistem-desa\resources\views/umum.blade.php ENDPATH**/ ?>